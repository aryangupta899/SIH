package com.sih.getlab.getlab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
